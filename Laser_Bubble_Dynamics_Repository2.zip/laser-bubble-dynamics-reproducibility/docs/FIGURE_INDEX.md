# Figure and calculation index

The image in figures/manuscript/ is the exact manuscript file. The outputs/ figure is a source-based redraw, with explicit units and panel labels; styling is not claimed to be pixel-identical.

## Figure 1 Editable implementation diagram

Figure 1. Implementation scope of the laser-driven bubble modeling framework. Experimental observations motivate three separate numerical variants: (A) single-bubble calculations with stored-energy feedback, bounded radial dynamics, event-triggered flashes and optical diagnostics (Figures 2–3); (B) an ensemble model with separate electron and heavy-particle thermal reservoirs and a logistic activation proxy (Figure 5); and (C) an extended ensemble incorporating an effective Saha closure, dimensionless loading feedback and delayed pressure pulses (Figure 6). Arrows indicate dependencies within each implementation. The Figure 3 transmission and absorption fractions are diagnostic outputs and do not modify the energy balance. Gate periods describe model modulation schedules rather than optical pulse durations. Dashed outlines identify additional physics and validation requirements. Numerical and energy-accounting limitations are discussed in Methods and Section 4.10; implemented components alone do not establish physical validation.

Run: `python reproduce.py --figure 1`

Inputs: `figures/editable/Figure1_editable.svg`, `figures/editable/Figure1_Microsoft_Equation_Editor.pptx`

Exact manuscript image preserved; SVG renders the corresponding diagram. Diagram components describe historical source branches.

## Figure 2 Original single-bubble algorithm

Figure 2. Outputs of the supplied single-bubble calculation under 60 s ON and 30 s OFF laser modulation. Panels (a–i) show radius, laser gate, stored-energy proxy, pressure, radial velocity, Mach number, burst flag, energy released at each trigger, and optical-signal proxy. The inset in (a) shows the minimum simulated radius in each completed OFF interval, plotted at the interval end. The radius and velocity retain the original clipping rules; burst energy is an event quantity, not cumulative energy. The 577 flags are outcomes of the original clipped algorithm. Figure 10 and Table 4 report the separate implicit reference, in which no collapse occurs.

Run: `python reproduce.py --figure 2`

Inputs: `components/historical_single/source_originals/figure2_updated.py`, `data/reference_arrays/historical_figure2.npz`

Clipped discrete source; 577 flags are numerical source outputs.

## Figure 3 Original extended single-bubble algorithm

Figure 3. Extended single-bubble source calculation. Panels (a–l) show radius and its lower bound, gate, energy proxy, uncalibrated temperature proxy E/C_e, pressure, velocity, burst flag, flash-power proxy, cumulative impulse, rupture indicator, transmission and absorption. The inset resolves the imposed bound. Panel (d) uses pre-event energy and is not a physical temperature in kelvin. Energy and flash-power units are nominal; optical and bound-growth coefficients are uncalibrated. Optical diagnostics do not feed the energy source. Parameters differ from Figure 2 (Table 1); repeated events disappear in the implicit reference (Figure 10).

Run: `python reproduce.py --figure 3`

Inputs: `components/historical_single/source_originals/figure3_updated.py`, `data/reference_arrays/historical_figure3.npz`

Loading and optical diagnostics retained; temperature ratio is uncalibrated.

## Figure 4 Author-confirmed submitted ensemble source

Figure 4. Reproduced original ensemble calculation, with the submitted image retained. From top to bottom: mean radius (µm), laser gate, mean energy proxy (source units), mean drive pressure (MPa), mean temperature proxy (nominal K) and camera response (arbitrary units), against time (ms). The eight-bubble source uses seed 4, Δt = 0.1 µs and 60/20 µs gating over 1 ms (Section 2.2). Eight flags occur in the first update; subsequent radii remain at the imposed 0.05 µm floor. The row labeled t = 0 is post-update. These outputs do not establish repeated physical collapse or plasma heating.

Run: `python reproduce.py --figure 4`

Inputs: `components/original_figure4/multibubble_fixed_full.py`, `components/original_figure4/results/arrays.npz`, `configs/figure4_submitted.json`

Original Figure 4, not the superseded corrected variant-6 initialization plot. Eight first-update flags and 50 nm floor.

## Figure 5 Original two-reservoir source

Figure 5. Ensemble response of the supplied two-reservoir thermal model with a logistic ionization proxy. From top to bottom, panels show mean radius (µm), laser gate, mean stored-energy proxy (J), mean local drive pressure (MPa), mean electron-reservoir temperature , and camera response (arbitrary units). Separate   and  balances are given in Eqs. (16a)–(16b); the Figure 5 ionization and pressure mappings are given in Eqs. (16i)–(16j).  is evolved internally but not plotted. Event-associated peaks are conditional simulation outputs; convergence and independent physical validation are not established. The horizontal axis is time (ms); wall velocity is not plotted. This is retained historical source output for the numerical audit; the repaired calculations are presented separately in Figure 12 and Table 6.

Run: `python reproduce.py --figure 5`

Inputs: `components/historical_ensemble/source_originals/figure5_two_reservoir_original.py`, `components/historical_ensemble/returned_arrays/figure5_returned_arrays.npz`

Logistic activation pressure mapping; source defects documented; no physical plasma validation.

## Figure 6 Original effective Saha/loading source

Figure 6. Extended ensemble time series. From top to bottom: mean radius (µm), laser gate (0/1), mean energy proxy (nominal J), mean overpressure (MPa), mean electron-reservoir temperature (K), mean effective Saha ionization fraction , mean dimensionless loading variable M and camera response (arbitrary units), against time (ms). In the supplied extended implementation,  is the fraction of the effective heavy-particle population in the singly ionized state, with , while the dimensionless loading index satisfies . This phenomenological index has no assigned mass in kilograms. Absorption/loading feedback, thermal exchange and delayed pressure pulses are specified in Eqs. (16a)–(16h). Pressure pulses are prescribed at fixed bubble locations; the calculation does not solve a spatial compressible shock field. The plotted means are model outputs rather than direct plasma or mass measurements. This is retained historical source output for the numerical audit; the repaired calculations are presented separately in Figure 12 and Table 6.

Run: `python reproduce.py --figure 6`

Inputs: `components/historical_ensemble/source_originals/figure6_extended_original.py`, `components/historical_ensemble/returned_arrays/figure6_returned_arrays.npz`

Historical source, distinct from corrected models; returned-array reproduction is checked.

## Figure 7 Source-derived pressure-threshold flag diagnostic

Figure 7. Illustrative cumulative threshold-flag fraction against time (ms). The supplied extended source uses eight irreversible pressure-impulse/peak-pressure flags, defined in Eqs. (16k)–(16l), with increments of 1/8 and a default-run final fraction of 5/8 = 0.625. The ordinate denotes activated numerical flags. No membrane geometry, constitutive relation or biological calibration is specified. The original plotted curve is retained; exact reproduction from the supplied source remains unverified.

Run: `python reproduce.py --figure 7`

Inputs: `components/historical_ensemble/returned_arrays/figure6_returned_arrays.npz`

Redrawn from t and rupt_frac. The original image generation history is not independently established; no biological rupture calibration is implied.

## Figure 8A Measured red diameter-growth characterization

Figure 8A. Descriptive characterization of the measured red growth trajectory underlying Figure 2 of Ref. [12]. (a) Measured squared diameter and its initial-expansion linear fit. (b) Measured diameter versus time. Both panels display 0–60 s; the fit includes the first recorded maximum at 60.54 s, just beyond the displayed range. The fitted line is an empirical regression, not a physical-model prediction. No literature growth-rate band is plotted because the squared-size convention of the reported range is not explicitly defined. Pointwise measurement error bars are omitted because their statistical meaning is undocumented.

Run: `python reproduce.py --figure 8A`

Inputs: `data/experimental/diameter_growth.xlsx`

Original workbook; first-expansion OLS; author-confirmed µm units; no pointwise Y-error bars or synthetic model curve.

## Figure 8B Four measured expansion-segment fits

Figure 8B. Descriptive comparison of the four measured expansion segments underlying Figure 2 of Ref. [12]. (a) Measured D² observations and a separate initial-expansion linear fit for each trace. (b) Corresponding fitted slopes with conventional 95% ordinary least-squares regression confidence intervals. These intervals describe conditional uncertainty in each fitted slope, not variability among independent experimental replicates. The colored lines are empirical fits rather than predictions of the physical model. Pointwise measurement error bars and the ambiguously defined literature growth-rate band are omitted.

Run: `python reproduce.py --figure 8B`

Inputs: `data/experimental/diameter_growth.xlsx`

Conditional slope intervals, not independent experimental-group tests; red/blue include cycles of one object.

## Figure 9 Discrete-source timestep/bound/event controls

Figure 9. Completed discrete-source controls. (a) Event counts as the timestep is reduced from 10 to 0.3125 ms. (b) Sampled flash integral divided by the assigned event-radiation proxy. (c) Event-count sensitivity to the imposed waiting time. The Figure 2 and Figure 3 event-count curves coincide. Apparent convergence of a clipped algorithm does not establish convergence to its continuous force equations.

Run: `python reproduce.py --figure 9`

Inputs: `components/historical_single/results/legacy_controls.json`

Algorithm controls; clipping is not physical-collapse convergence.

## Figure 10 Unclipped continuous source references

Figure 10. Implicit continuous-equation references. (a) Radius displacement over 300 s and (b) startup on a logarithmic time axis. Both sources approach pressure-capped equilibria near 2 µm. The curves solve the supplied spring–damping equations without radius or velocity clipping; they are not a replacement Rayleigh–Plesset model and show no collapse events.

Run: `python reproduce.py --figure 10`

Inputs: `components/historical_single/results/continuous_figure2_reference.npz`, `components/historical_single/results/continuous_figure3_reference.npz`

Original spring-damping equations; zero collapse, not a replacement model.

## Figure 11 Implementation-specific mechanism controls

Figure 11. Implementation-specific mechanism controls. (a) Stored energy with quenching off and on in the archived reconstruction over 1 s at 0.1 ms; energy units are nominal labels from that code. (b) New three-bubble dynamic pressure-coupling diagnostic over 2 s at center spacings of 40, 100 and 200 µm. Radius on/off differences are compared with coupling-on refinement differences. The similar scales do not establish a resolved spacing effect; the cases do not recover the original ensemble source.

Run: `python reproduce.py --figure 11`

Inputs: `components/historical_single/results/reconstructed_quench_0.npz`, `components/historical_single/results/reconstructed_quench_0.65.npz`, `components/historical_single/results/new_dynamic_coupling_controls.json`

Quenching applies to archived reconstruction; three-bubble coupling diagnostic is separately declared.

## Figure 12 Corrected energy-consistent ensembles

Figure 12. Corrected effective-reservoir ensemble calculations. Left and right columns show the variants derived from the historical Figure 5 and Figure 6 sources. (a,b) Mean radius on a logarithmic time axis; (c,d) mean thermal states and matched one-temperature controls; (e,f) cumulative initial threshold crossings; (g,h) global energy-ledger residual normalized by integrated absorbed energy. Both variants retain five initial crossings but no repeated hot-plasma event train. The event rule is a prescribed conservative diagnostic; it is not a measured optical-flash detector. All new outputs use adaptive integration without state clipping.

Run: `python reproduce.py --figure 12`

Inputs: `components/corrected_models/results/corrected_figure5.npz`, `components/corrected_models/results/corrected_figure6.npz`

Conditional numerical verification; no repeated hot-plasma flashes.

## Figure 13 Separate finite-rate phase-change model

Figure 13. Executed phase-change controls for a separate assumed air/water-vapor cavity. (a) Radius with phase change ON/OFF; (b) heated interface/absorber-node and gas temperatures for the ON case; (c) vapor mass relative to its initial value; (d) total-energy residual normalized by absorbed energy. The assumed reference pulse train is 250 mW, 100 kHz and 100 ns, with absorption fraction 10⁻⁴ and accommodation 10⁻³. Mass transfer and transfer enthalpy are coupled to inertia and thermal energy. These conditional 30 µs calculations are not fits to experimental flash or minute-scale growth measurements.

Run: `python reproduce.py --figure 13`

Inputs: `components/corrected_models/results/phase_on.npz`, `components/corrected_models/results/phase_off.npz`

Pre-existing air/water-vapor cavity; 30 µs under assumed transfer inputs; not fitted to minute-scale growth.
