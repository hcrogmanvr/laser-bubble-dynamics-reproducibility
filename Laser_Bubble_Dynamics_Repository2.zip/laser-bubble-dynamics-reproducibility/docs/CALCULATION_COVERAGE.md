# Calculation coverage

The repository is organized by the implementation that actually generated each result, rather than treating the conceptual equations as one calibrated physical model.

| Manuscript group | Implementation or record | Coverage |
| --- | --- | --- |
| Equations 1–9 and 9a–9b | Native formulas in docs/equations; Figure 2–3 and ensemble source-specific mappings | Conceptual absorber/optics/thermal definitions distinguished from actual code. Parameters marked unspecified in Table 1 are not invented. General shell-volume, attenuation and unit-conversion helpers are in scripts/reference_calculations.py. |
| Equations 10 and 10a–10f | components/historical_single/source_originals and code/run_controls.py | Exact discrete updates, local damping-scale calculation, implicit continuous source references and declared dynamic-coupling diagnostic. |
| Equations 11–16 | Original source files for each figure | Event thresholds, energy removal and optical/camera mappings are reproduced according to each source version, rather than asserted to be common across figures. |
| Equations 16a–16m | components/historical_ensemble/source_originals; reproduce_defaults.py; diagnostics/density_check.py | Historical two-reservoir, logistic/effective Saha, absorption/loading, delayed-pulse and pressure-flag definitions; paired density scale recorded. |
| Equation 16n | components/historical_ensemble/diagnostics/coupling_check.py | Restricted event-phase statistic on the declared active subset; no all-eight statistic is invented when phases are undefined. |
| Equations 16o–16r | components/corrected_models/code/corrected_ensemble.py | Corrected radial inertia, thermal work/ionization accounting, conservative threshold removal and conditional Drude/slab power accounting. |
| Equations 16s–16t | components/corrected_models/code/phase_change.py | Existing-cavity vapor flux, IAPWS pressure, transfer enthalpy and coupled thermal/mechanical balances. |
| Equations 16u–16z | components/original_figure4/multibubble_fixed_full.py | Confirmed submitted Figure 4; fixed seed, geometry, pumping, inverse-cube coupling, clipping, trigger/reset and camera recurrence. |
| Equations 17–19 | Conceptual transfer balances; implemented separate closure in corrected phase_change.py | Diagnostic/conservation formulations, not an additional long-time fitted model. |
| Equation 20 | Historical effective pressure mappings and corrected source definitions | Species/temperature assumptions remain explicit. No chemical validation is claimed. |
| Equations 21–22 | Historical/corrected comparison and refinement records | No experimental radius goodness-of-fit value is invented when the dynamical model has not been fitted. Numerical differences and ledger checks are supplied. |
| Experimental fits | scripts/plot_paper_figures.py growth_analysis | Four initial-expansion OLS fits to the actual diameter workbook; no ambiguous pointwise error bars. |
| Independent benchmarks | components/corrected_models/code/run_suite.py | Finite-radius Rayleigh integral, 70-digit Decimal Saha algebra, Drude budget, exact thermal exchange, event-jump accounting and saturation endpoints. |

The 108 native expressions include inline mathematics as well as numbered display equations. docs/equation_index.json associates each preserved Office Math XML fragment with its original paragraph label. Linear tokens in that JSON are an index, not a replacement for structured fraction/subscript/superscript layout.

Numerical verification is not experimental validation of a plasma EOS, quenching, an emission mechanism, magnetic control or biological injury.
