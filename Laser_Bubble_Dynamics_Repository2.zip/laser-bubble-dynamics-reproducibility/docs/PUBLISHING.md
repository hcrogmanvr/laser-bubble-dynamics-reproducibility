# Publishing this prepared repository

Suggested repository name: laser-bubble-dynamics-reproducibility

Suggested description:
Code, data and reproducible figures for laser-driven bubble dynamics, numerical controls, phase-change models and experimental growth characterization.

This package is locally prepared and verified. No live GitHub repository URL or DOI has been assigned.

## Import the source ZIP

1. Extract the ZIP and enter the repository folder.
2. Create an empty GitHub repository under the desired account or organization.
3. Initialize/push the source files using Git, or import the supplied Git bundle if available.
4. Keep the first hosted copy private while reviewing the scientific content and reuse terms; choose visibility deliberately when ready.

    git init -b main
    git add .
    git commit -m "Add manuscript reproduction code and data"
    git remote add origin https://github.com/OWNER/laser-bubble-dynamics-reproducibility.git
    git push -u origin main

Replace OWNER with the actual chosen account. The example is a command template, not an existing repository URL.

## Import a Git bundle

    git clone Laser_Bubble_Dynamics_Repository.bundle laser-bubble-dynamics-reproducibility
    cd laser-bubble-dynamics-reproducibility
    git remote remove origin
    git remote add origin https://github.com/OWNER/laser-bubble-dynamics-reproducibility.git
    git push -u origin main

The Git clone contains tracked code, inputs, exact manuscript images and archived numerical records. Runtime outputs/ are ignored and can be regenerated with python reproduce.py --mode verify. The ZIP release also includes the completed outputs and validation report for inspection.

## Before assigning a paper repository citation

Use the actual hosted URL after the files are uploaded. Select code/data licensing terms, make a tagged release corresponding to the manuscript revision, and obtain a real archive DOI if desired. Update CITATION.cff and the manuscript data-availability statement with that real URL/identifier. Never use a placeholder DOI.
