# Data dictionary and units

- Original single-bubble Figure 2–3 arrays retain SI radius/time/speed and nominal pressure assignments. E, flash energy and detector scales are source proxies rather than calibrated optical joules/watts.
- Original Figure 4: t in seconds; R in meters; E in source units; P in assigned Pa; Te is 300 + 2500 log1p(E), a nominal-K proxy; burst is source energy per saved step; cam is an arbitrary detector state; pos in meters. Each saved row is post-update but labeled with its current grid time, including t=0.
- Historical ensemble arrays: t in seconds, R_mean in meters; Te_mean in nominal kelvin; E_mean nominal J; pressure fields already labeled MPa; xion_mean is an effective fraction; M_mean dimensionless; rupt_frac is a numerical pressure-flag fraction.
- Corrected ensemble: independent output t_us is in microseconds; R in meters, v in m/s, Te/Ti in kelvin, pb in Pa; events columns are [time_us, zero-based bubble index, removed_J]; energy_residual_J in joules. Internal solver state coordinates are scaled; use the named observable arrays and documented code for interpretation.
- Phase model: t_us in microseconds; R_m in meters; Twall_K/Tgas_K in kelvin; vapor mass and normalized mass fields are defined in phase_change.py; energy accounting is in joules.
- Workbook: first recorded coordinate in minutes, diameter in µm after author unit confirmation. Output time_s converts minutes to seconds. D2_um2 is squared diameter, not squared radius. Growth slopes are µm²/s.
- Figure 8B slope intervals are conditional OLS 95% intervals; their error bars are distinct from the omitted pointwise measurement Y-error bars.
- outputs/plotted_data/Figure*.csv.gz files use a first column named time; the plotted time unit is s for Figures 2–3, ms for Figures 4–7. The original SI-time arrays remain in each component. Column headers declare plotted ordinate units.
- All random seeds and case-specific inputs are in configs/ and the original source records. No geometry is redrawn during a plot-only run.
