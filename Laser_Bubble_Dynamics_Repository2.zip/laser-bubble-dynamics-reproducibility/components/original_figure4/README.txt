Author-identified submitted Figure 4 source and actual execution

multibubble_fixed_full.py transcribes the code supplied in the author's latest message. The equations, parameters, update order and original six-panel plot are unchanged. run_and_export.py captures plt.show() headlessly and exports arrays and plotted coordinates. No source repair or solver change is made.

Run: python run_and_export.py
Dependencies: numpy, matplotlib.
Results: results/Figure4_author_source.png, .pdf, .svg; arrays.npz; plotted_points.csv; run_summary.json.
run_log.txt contains the actual console output.

The default run uses eight bubbles, seed 4, 1 ms duration, 100 ns timestep, absorption fraction 0.25, energy relaxation 80 microseconds, burst fraction 0.7, rebound factor 0.6, coupling 0.12 and camera gain 0.002. These differ from the earlier pasted 5 ms/50 ns version.

The six-panel output visually reproduces the curve behavior and scales in the earlier manuscript Figure 4: an initial drop in mean radius to 0.05 micrometers, 60/20 microsecond gating, energy/pressure/temperature proxy modulation and a camera response with initial maximum 0.0028 followed by decay. This is visual agreement, not a pixel-for-pixel image identity claim. The supplied plot retains its title and export styling.

Eight burst flags occur at the first recorded step, labeled t=0. All later saved radii equal the imposed 50 nm lower bound. The temperature proxy reaches 300.0417369 K and drive-pressure proxy reaches 0.0058432044 MPa. The loop saves post-update states; the assigned 0.581–0.783 micrometer initial radii are not stored as an initial-state row. run_summary.json records the recovered assigned radii.

The code source/configuration gap is now resolved by the author's supplied source. Numerical reproducibility alone does not establish convergence or a physical collapse mechanism. This exact run does not produce a repeating expansion-collapse sequence. Acceleration, velocity and radius clipping, the proxy pressure/temperature maps and prescribed camera response remain part of the algorithm.

The prior corrected-model replacement Figure 4 is a different calculation. It is not a repaired replot of this source. This package does not alter the current manuscript or reviewer response.
