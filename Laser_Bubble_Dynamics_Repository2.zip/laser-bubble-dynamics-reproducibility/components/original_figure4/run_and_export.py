"""Execute the author-identified submitted Figure 4 source without model changes."""
from pathlib import Path
from unittest.mock import patch
import runpy,json,inspect,hashlib,platform
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
DEST=ROOT/'results'
DEST.mkdir(exist_ok=True)
def capture(*args,**kwargs):
    fig=plt.gcf()
    for ext in ['png','pdf','svg']:fig.savefig(DEST/('Figure4_author_source.'+ext),dpi=180,bbox_inches='tight')
    plt.close(fig)
with patch('matplotlib.pyplot.show',capture):
    ns=runpy.run_path(str(ROOT/'multibubble_fixed_full.py'),run_name='__main__')
a=ns['out'];np.savez_compressed(DEST/'arrays.npz',**a)
event_rows=np.flatnonzero(a['burst'].sum(axis=1)>0)
defaults={k:v.default for k,v in inspect.signature(ns['simulate_multibubble']).parameters.items()}
summary=dict(source='Code identified by the author as submitted Figure 4 source',
             parameters=defaults,medium=vars(ns['medium']),camera=vars(ns['cam']),
             samples=len(a['t']),total_burst_flags=int(ns['total_bursts']),
             event_rows=event_rows.tolist(),event_times_s=a['t'][event_rows].tolist(),
             initial_assigned_radii_um=(a['R'][0]*0).tolist(),
             min_saved_radius_um=float(a['R'].min()*1e6),max_saved_radius_um=float(a['R'].max()*1e6),
             fraction_saved_radii_at_R_min=float(np.mean(a['R']==defaults['R_min'])),
             max_temperature_proxy_K=float(a['Te'].max()),max_drive_pressure_MPa=float(a['P'].max()/1e6),
             max_camera_signal=float(a['cam'].max()),all_arrays_finite=all(np.isfinite(v).all() for v in a.values()),
             python=platform.python_version(),numpy=np.__version__,matplotlib=matplotlib.__version__,
             source_sha256=hashlib.sha256((ROOT/'multibubble_fixed_full.py').read_bytes()).hexdigest())
# Reconstruct assigned initial radii with the exact accepted position RNG sequence.
rng=np.random.default_rng(defaults['seed']);pos=[]
for _ in range(defaults['n_bubbles']):
    for _try in range(5000):
        p=rng.normal(scale=defaults['r0'],size=3)
        if all(np.linalg.norm(p-q)>2.5e-6 for q in pos):pos.append(p);break
    else:pos.append(rng.normal(scale=defaults['r0'],size=3))
assert np.array_equal(np.array(pos),a['pos'])
summary['initial_assigned_radii_um']=(defaults['R0']*(1+.08*rng.normal(size=defaults['n_bubbles']))*1e6).tolist()
(DEST/'run_summary.json').write_text(json.dumps(summary,indent=2))
columns=[a['t'],a['R'].mean(axis=1)*1e6,a['E'].mean(axis=1),a['P'].mean(axis=1)/1e6,a['Te'].mean(axis=1),a['laser'],a['burst'].sum(axis=1),a['cam']]
np.savetxt(DEST/'plotted_points.csv',np.column_stack(columns),delimiter=',',header='time_s,mean_radius_um,mean_energy_source_units,mean_drive_pressure_MPa,mean_temperature_proxy_K,laser_gate,event_energy_source_units,camera_source_units',comments='')
print(json.dumps(summary,indent=2))
