from pathlib import Path
import json,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
ROOT=Path(__file__).resolve().parents[1]; R=ROOT/'results'; F=ROOT/'figures';F.mkdir(exist_ok=True)
load=lambda n:json.loads((R/(n+'.json')).read_text())
legacy=load('legacy_controls');conv=load('continuous_convergence');couple=load('new_dynamic_coupling_controls');quench=load('reconstructed_quenching_control')
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':220})
colors=['#225b8d','#b44d31']
fig,ax=plt.subplots(1,3,figsize=(10.5,3.2))
for model,col in zip([2,3],colors):
 rr=[x for x in legacy if x['model'].startswith(f'Figure {model}') and x['test']=='timestep'];dt=[x['dt_s'] for x in rr]
 ax[0].plot(dt,[x['events'] for x in rr],'o-',color=col,label=f'Figure {model}')
 ax[1].plot(dt,[x['sampled_flash_integral_proxy']/x['radiated_event_energy_proxy'] for x in rr],'o-',color=col)
 rr=[x for x in legacy if x['model'].startswith(f'Figure {model}') and x['test']=='bound_or_event_rule' and x['parameter']=='cooldown_factor']
 ax[2].plot([x['factor']*.5 for x in rr],[x['events'] for x in rr],'o-',color=col)
for a in ax[:2]:a.set_xscale('log');a.set_xlabel('Timestep (s)');a.invert_xaxis()
ax[0].set_ylabel('Event count in 300 s');ax[0].legend(frameon=False)
ax[1].set_ylabel('Sampled flash integral / event radiation');ax[1].axhline(1,color='gray',ls='--',lw=1)
ax[2].set(xlabel='Imposed waiting time (s)',ylabel='Event count in 300 s')
for i,a in enumerate(ax):a.text(.01,1.04,chr(97+i),transform=a.transAxes,fontweight='bold')
fig.tight_layout();fig.savefig(F/'discrete_controls.png');plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(10.5,3.3))
for model,col in zip([2,3],colors):
 s=np.load(R/f'continuous_figure{model}_reference.npz');d=(s['R'][0]-2e-6)*1e9
 ax[0].plot(s['t'],d,color=col,label=f'Figure {model}')
 mask=(s['t']>0)&(s['t']<.1);ax[1].semilogx(s['t'][mask],d[mask],color=col)
ax[0].set(xlabel='Time (s)',ylabel='Radius displacement from 2 µm (nm)');ax[0].legend(frameon=False)
ax[1].set(xlabel='Time after start (s)',ylabel='Radius displacement from 2 µm (nm)')
for i,a in enumerate(ax):a.text(.01,1.04,chr(97+i),transform=a.transAxes,fontweight='bold')
fig.tight_layout();fig.savefig(F/'continuous_reference.png');plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(10.5,3.3))
for q,label,c in [(0,'Quenching off',colors[0]),(.65,'Quenching on',colors[1])]:
 s=np.load(R/f'reconstructed_quench_{q:g}.npz');ax[0].plot(s['t'],s['energy_J'],label=label,color=c)
ax[0].set(xlabel='Time (s)',ylabel='Stored energy (nominal J)');ax[0].legend(frameon=False)
for model,col in zip([2,3],colors):
 rr=[x for x in couple if x['model'].startswith(f'Figure {model}')]
 ax[1].semilogy([x['spacing_um'] for x in rr],[x['max_radius_on_off_difference_nm'] for x in rr],'o-',color=col,label=f'Figure {model} on/off')
 ax[1].semilogy([x['spacing_um'] for x in rr],[x['max_radius_refinement_difference_nm'] for x in rr],'x--',color=col,label=f'Figure {model} refinement')
ax[1].set(xlabel='Center spacing (µm)',ylabel='Maximum radius difference (nm)');ax[1].legend(frameon=False,fontsize=8)
for i,a in enumerate(ax):a.text(.01,1.04,chr(97+i),transform=a.transAxes,fontweight='bold')
fig.tight_layout();fig.savefig(F/'mechanism_controls.png');plt.close(fig)

D=Document();sec=D.sections[0];sec.page_width=Inches(8.5);sec.page_height=Inches(11);sec.top_margin=sec.bottom_margin=Inches(.65);sec.left_margin=sec.right_margin=Inches(.7)
for name in ['Normal','Title','Heading 1','Heading 2','Caption']:
 st=D.styles[name];st.font.name='Times New Roman';st.font.color.rgb=RGBColor(0,0,0)
D.styles['Normal'].font.size=Pt(11);D.styles['Normal'].paragraph_format.space_after=Pt(7);D.styles['Normal'].paragraph_format.line_spacing=1.05
D.styles['Title'].font.size=Pt(20);D.styles['Heading 1'].font.size=Pt(15);D.styles['Heading 2'].font.size=Pt(12)
D.core_properties.title='Numerical controls and manuscript revision';D.core_properties.subject='Source reproduction, numerical verification and mechanism controls'
D.core_properties.author='Horace T. Crogman'

def p(t,red=False,style=None):
 pp=D.add_paragraph(style=style);run=pp.add_run(t)
 if red:run.font.color.rgb=RGBColor.from_string('C00000')
 if pp._p.getprevious() is not None and pp._p.getprevious().tag==qn('w:tbl'):pp.paragraph_format.space_before=Pt(6)
 return pp

def h(t):D.add_heading(t,level=1)
def table(headers,rows,widths=None):
 tb=D.add_table(rows=1,cols=len(headers));tb.alignment=WD_TABLE_ALIGNMENT.CENTER;tb.autofit=False
 if widths:
  for c,w in zip(tb.columns,widths):c.width=Inches(w)
 for c,t in zip(tb.rows[0].cells,headers):c.text=t
 rep=OxmlElement('w:tblHeader');tb.rows[0]._tr.get_or_add_trPr().append(rep)
 for row in rows:
  for c,t in zip(tb.add_row().cells,row):c.text=str(t)
 for i,row in enumerate(tb.rows):
  trpr=row._tr.get_or_add_trPr();ns=OxmlElement('w:cantSplit');trpr.append(ns)
  for j,c in enumerate(row.cells):
   if widths:c.width=Inches(widths[j])
   c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER;pr=c._tc.get_or_add_tcPr()
   bord=OxmlElement('w:tcBorders')
   for side in ['top','left','bottom','right']:
    edge=OxmlElement('w:'+side);edge.set(qn('w:val'),'single');edge.set(qn('w:sz'),'4');edge.set(qn('w:color'),'D9D9D9');bord.append(edge)
   pr.append(bord);mar=OxmlElement('w:tcMar')
   for side in ['top','left','bottom','right']:
    e=OxmlElement('w:'+side);e.set(qn('w:w'),'85');e.set(qn('w:type'),'dxa');mar.append(e)
   pr.append(mar)
   if i==0:
    sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E7EDF3');pr.append(sh)
   for pp in c.paragraphs:
    pp.paragraph_format.space_after=Pt(1);pp.paragraph_format.space_before=Pt(1)
    if j>0:pp.alignment=WD_ALIGN_PARAGRAPH.CENTER
    for run in pp.runs:run.font.size=Pt(9);run.bold=(i==0)
 return tb

def picture(name,caption):
 pp=D.add_paragraph();pp.paragraph_format.keep_with_next=True;pp.add_run().add_picture(str(F/name),width=Inches(7.05));p(caption,style='Caption')
def page():D.add_page_break()

p('Numerical controls and manuscript revision',style='Title')
p('Laser driven multi bubble collapse and plasma mediated optical flashes')
p('The completed controls identify a numerical failure in the supplied Figure 2 and Figure 3 implementations. Their reported 577 collapse events do not persist when the continuous spring–damping equations are integrated without radius and velocity clipping. The present results support a reproducibility correction and narrower manuscript claims; they do not validate the original flash mechanism.')
h('Completed tests and their scope')
table(['Control','Execution','Result'],[
['Timestep and hard bounds','Original Figure 2 and Figure 3 algorithms','Clipping remains active at every update'],
['Forcing and gate schedules','Both discrete sources and implicit references','No collapse in the implicit references'],
['Quenching on and off','Archived reconstructed model only','Energy changes; no collapse in the 1 s test'],
['Coupling on and off','Archived reconstruction','Dynamic states are identical'],
['Spacing and dynamic coupling','New three bubble extension only','No collapse; spacing response unresolved']],[1.55,2.4,3.1])
h('Source provenance')
p('The untouched figure2_updated.py and figure3_updated.py files were recovered from the supplied Figure 2 and Figure 3 ZIP packages. An optimized audit loop reproduces all checked source arrays with maximum error relative to their peak below 1.7 × 10⁻¹³. The separate Laser_MultiBubble_Model archive explicitly describes itself as a reconstruction made without the original source scripts. Its results therefore cannot be attributed to the manuscript’s original Figures 4–6.')
p('The accompanying package preserves these source files, hashes, executable controls, CSV tables, full reference arrays and figure generation code. The energy coefficients in the original figure sources are treated as model proxies because their dimensional calibration has not been established.')
p('Report contents: discrete controls and optical sampling; implicit integration and refinement; mechanism controls; red manuscript replacement text; reviewer response and remaining work.')
page();h('Discrete controls and optical sampling')
p('All source tests span 300 s. The timestep was reduced from 10 ms to 0.3125 ms. The radius floor, radius ceiling, speed limit, pressure ceiling and event waiting time were separately multiplied by 0.5, 1 and 2. The forcing multiplier was swept over 0.5, 0.75, 1, 1.25 and 1.5. Gate schedules were 30/60, 45/45, 60/30 and 75/15 s ON/OFF at fixed peak source.')
picture('discrete_controls.png','Figure S1. (a) Event counts under timestep refinement. (b) Sampled flash integral divided by the event radiation proxy. (c) Sensitivity to the imposed waiting time. Figure 2 and Figure 3 event-count curves coincide. Refining this clipped algorithm does not establish convergence to the continuous force balance.')
table(['Timestep ms','Events both','Figure 2 flash ratio','Figure 3 flash ratio'],[[f"{x['dt_s']*1000:g}",x['events'],f"{x['sampled_flash_integral_proxy']/x['radiated_event_energy_proxy']:.4f}",f"{y['sampled_flash_integral_proxy']/y['radiated_event_energy_proxy']:.4f}"] for x,y in zip([z for z in legacy if z['model'].startswith('Figure 2') and z['test']=='timestep'],[z for z in legacy if z['model'].startswith('Figure 3') and z['test']=='timestep'])],[1.25,1.25,2.25,2.3])
p('Both the radius and speed are clipped at 100% of updates at every tested timestep. Halving or doubling the radius ceiling changes the maximum radius directly from 30 µm to 15 or 60 µm. Changing the waiting time from 0.5 s to 0.25 or 1 s gives 1,154 or 295 events. Unchanged event counts under several other bounds therefore indicate masking by the clipping and trigger rules, rather than physical robustness.')
p('At the original 10 ms timestep, the 2 ms exponential flash decay is undersampled. The sampled integral is about 5.034 times the assigned radiation proxy; even at 0.3125 ms the ratio is about 1.080. These traces cannot establish experimental flash duration or calibrated intensity. No spectral prediction is implemented.')
page();h('Implicit integration and numerical refinement')
p('The original force balance was integrated with Radau, retaining its spring, damping, inertia, forcing and pressure ceiling while removing radius and speed clamps. Energy was integrated analytically between laser switches on the branch without events. A downward crossing of the original collapse radius terminates the reference calculation; none occurred. The source floor never becomes active along these trajectories.')
picture('continuous_reference.png','Figure S2. (a) Radius displacement over 300 s and (b) startup response on a logarithmic time axis. The two sources approach pressure capped equilibria near 2 µm. These are solutions of the supplied spring–damping equations, not a replacement Rayleigh–Plesset model.')
table(['Source','Relative tolerance','Max step s','Max displacement nm','Difference from finest nm'],[[str(2 if x['model'].startswith('Figure 2') else 3),f"{x['rtol']:.0e}",f"{x['max_step_s']:g}",f"{x['R_max_excursion_nm']:.6f}",f"{x['max_radius_difference_from_finest_nm']:.2e}"] for x in conv],[.6,1.35,1.1,1.8,2.2])
p('Radius is scaled by 1 nm and velocity by 10⁻⁶ m/s. Absolute radius tolerances are 10⁻⁷, 10⁻⁹ and 10⁻¹¹ nm; velocity tolerances are 10⁻¹⁰, 10⁻¹² and 10⁻¹² m/s, respectively. Time restarts locally at each gate boundary. Differences are evaluated on a shared grid with dense startup and switching samples; they are empirical refinement indicators, not rigorous global error bounds.')
p('The damping relaxation times are 3.33 × 10⁻¹⁷ s and 8.38 × 10⁻¹⁹ s. The original explicit update has corresponding linear fast-mode stability limits of approximately 6.67 × 10⁻¹⁷ s and 1.68 × 10⁻¹⁸ s. The source timesteps are far above these limits. In all forcing, gate schedule and pressure ceiling tests, the implicit references produce zero events. Halving/doubling the pressure ceiling changes maximum displacements to 0.754/3.025 nm and 0.838/3.362 nm, respectively.')
page();h('Mechanism controls and spacing')
picture('mechanism_controls.png','Figure S3. (a) Quenching control in the archived reconstruction over 1 s at 0.1 ms. Energy units are nominal model units labelled J in that archive. (b) New pressure mediated coupling extension for three bubbles over 2 s. On/off differences and changes under numerical refinement are of similar order, so a quantitative spacing effect is unresolved.')
p('In the archived reconstruction, changing quenching strength from 0 to 0.65 reduces integrated absorbed energy from 0.429572 to 0.150352 nominal J, a 65.00% reduction. Stored energy at 1 s decreases from 0.245228 to 0.085830 nominal J. Both cases end at the 30 µm radius ceiling, reach the pressure ceiling at 99.99% of stored samples and generate zero collapse events. This demonstrates an implemented energy suppression term, not validated plasma physics or flash suppression.')
p('For Figure 3, varying the diagnostic optical depth multiplier over 0.5, 1 and 2 changes transmission and absorptance, but every dynamic state is unchanged. Its computed optical diagnostics do not feed back into energy input. The original Figure 2 source also contains no absorption quenching term.')
p('For the archived three bubble implementation, coupling strength 0 versus 0.08 at identical seed 7 over 0.1 s gives exactly zero differences in radius, velocity, energy, temperature, burst energy and camera signal. Only the postprocessed pressure changes, by up to 391,894 Pa. The implementation has no spacing parameter and cannot test collective collapse dynamics.')
p('A new diagnostic extension places three equal bubbles on a line at center spacings 40, 100 and 200 µm and adds the neighboring volume acceleration pressure inside the force equations. The original coefficients and per bubble source are held fixed. All six spacing cases have zero events. Maximum radius on/off differences are 8.9 × 10⁻¹²–3.1 × 10⁻¹¹ nm for Figure 2 coefficients and 2.6 × 10⁻⁹–2.9 × 10⁻⁹ nm for Figure 3 coefficients. These are not clearly separated from refinement differences. No synchronization or flash enhancement is established.')
p('This extension assumes fixed spherical bubbles and instantaneous far field pressure exchange. Propagation delay, translation, deformation, phase change, thermal exchange and optical shielding are absent. Its earliest stiff transients are outside the instantaneous acoustic approximation. It is a code diagnostic, not a validated collective cavitation model.')
page();h('Red manuscript replacement text')
p('Use the following text to replace the numerical verification and robustness claims. Sections that interpret the original 577 events as physical collapse or optical flash predictions must be revised consistently before submission.')
h('Numerical verification')
p('We performed explicit control calculations for the supplied Figure 2 and Figure 3 implementations. The source outputs were first reproduced using their original update rules. We then reduced the timestep from 10 ms to 0.3125 ms, varied the imposed numerical bounds and event waiting time, and swept the forcing multiplier and laser gate schedule. Both source algorithms clipped radius and speed at every update at every tested timestep. Event counts changed from 577 to 600 under refinement and from 295 to 1,154 when the prescribed waiting time was changed from 1 to 0.25 s. These results show that the reported repeated events depend strongly on the discrete clipping and trigger rules.',True)
p('We separately integrated the continuous spring–damping force balance underlying each source using an implicit stiff solver, without radius or speed clipping and with the original pressure ceiling retained. At the finest settings, the maximum outward displacements from the initial 2 µm radius were 1.510 nm and 1.678 nm for the Figure 2 and Figure 3 coefficients, respectively. Neither reference crossed its collapse threshold during 300 s, and no collapse events occurred in the associated forcing, gate schedule or pressure ceiling sweeps. The original repeated event traces therefore cannot be interpreted as numerically verified predictions of physical cavitation collapse.',True)
p('The original 10 ms sampling interval also exceeds the prescribed 2 ms optical decay time. The sampled flash integral is approximately 5.034 times the assigned radiation proxy at that resolution and remains about 1.080 times the proxy at the finest tested discrete timestep. Accordingly, we do not infer experimental flash duration, absolute intensity or spectral content from these signals. The source energy coefficients are retained as phenomenological proxies pending a consistent dimensional calibration.',True)
h('Scope of mechanism controls')
p('The supplied Figure 2 and Figure 3 energy equations do not implement plasma induced absorption quenching. In Figure 3, changing the optical depth diagnostic changes transmission and absorptance without changing the dynamic solution. A separate archived reconstruction contains an explicit quenching term; its 1 s on/off control reduces absorbed energy by approximately 65%, but both cases generate zero collapse events and remain dominated by imposed bounds. This result is specific to that reconstruction.',True)
p('The archived multi bubble routine modifies pressure only after independent trajectories have been computed, and its coupling switch leaves all dynamic states unchanged. A separately identified extension that inserts pressure mediated interactions into the source force equations was tested at center spacings of 40, 100 and 200 µm. It produced no collapse events and no spacing response clearly resolved above numerical refinement differences. These calculations do not support a claim of validated collective flash enhancement.',True)
page();h('Reviewer response supported by the controls')
p('We thank the reviewer for requesting explicit controls and numerical verification. We have completed timestep, bound, event rule, forcing and gate schedule sweeps for the supplied Figure 2 and Figure 3 implementations, together with implicit integration of their continuous force equations. The controls revealed a substantive limitation: the repeated events in the original clipped algorithms do not persist in the implicit references. We therefore cannot retain the interpretation of these events as quantitatively verified collapse or flash predictions. The control data and executable scripts are supplied for reproducibility.',True)
p('We also tested the mechanisms actually present in the available code. The original Figure 2 and Figure 3 energy equations have no absorption quenching feedback. A quenching control in a separately archived reconstruction demonstrates energy suppression only within that implementation. Its multi bubble coupling is postprocessing and has no effect on trajectories. A new, explicitly identified pressure coupling extension was tested over three spacings, without establishing a resolved collective effect. We now distinguish source reproduction, numerical verification, exploratory extensions and experimental validation. Quantitative experimental flash validation remains outstanding.',True)
h('Required scientific revision')
p('The manuscript needs a consistent physical implementation before positive collapse and flash conclusions can be restored. The continuous equations, parameter units and source code must agree; a stable integrator alone does not repair the present mechanical model. Reassess the spring and damping coefficients and dimensional energy closure before fitting any parameters to recover event counts.')
p('Implement any claimed quenching and dynamic coupling inside that same validated time integration. Phase change, heat and mass transfer, a stated equation of state, and any ionization closure require explicit equations and justified parameters. Their necessity and level of approximation should be evaluated against the experimental regime rather than inferred from the present event traces.')
p('After a physically consistent baseline exists, rerun controls with fixed inputs, geometry and initial conditions. Separate fixed peak power from fixed deposited energy comparisons. Compare flash duration, intensity and spectra only against measured signals with documented detector response and uncertainties. Retain the experimental bubble growth fits as a separate empirical result; they do not validate the optical mechanism.')
h('Reproducing this audit')
p('Install the versions recorded in requirements.txt, run python code/run_controls.py, then python code/verify_results.py and python code/build_report.py. These commands regenerate tables, arrays, figures and this document. The README and dynamic_coupling_equations.md specify scope, coefficients, signs and assumptions. The supplied source files are preserved unchanged; optimized reproduction errors and SHA256 hashes are recorded in results/.')
p('Numerical method reference: SciPy solve_ivp documentation, https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.solve_ivp.html. The reported refinement is an internal consistency check of the implemented source equations, not experimental validation.')
for style in D.styles:
 for node in list(style.element.iter(qn('w:pBdr'))):node.getparent().remove(node)
for node in list(D.element.iter(qn('w:pBdr'))):node.getparent().remove(node)
OUT=ROOT/'Reviewer_Controls_Results_and_Red_Revision.docx';D.save(OUT);print(OUT)
